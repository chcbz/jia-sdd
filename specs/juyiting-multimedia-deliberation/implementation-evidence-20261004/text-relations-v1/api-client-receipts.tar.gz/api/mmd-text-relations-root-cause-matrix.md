# Text delivery relation test root-cause matrix
Scope: source-only Java tests under the user's standing authorization to continue development. No production, Provider, deployment or release actions.

| Attempt | Evidence | Verified cause | Correction |
| --- | --- | --- | --- |
| v1 | /var/tmp/mmd-text-relations-tests-v1-20261004/chat-v1.log | New test uses LinkedHashMap without importing java.util.LinkedHashMap; production compiled | a0f977ab adds the missing import |
| v2 | /var/tmp/mmd-text-relations-tests-v2-20261004/chat-v1.log | Mockito when is still being assembled while a real reader calls the other mocks inside thenReturn's argument; 108 other tests passed | a71d6d72 computes the actual parent read before entering when |

Remediation changes only the two test fixtures. No assertion is removed, no skipped test, no AP/ordinary graph changes. The next run must keep all eleven selected suites on the exact new commit/tree, and retain both failed logs. This completed matrix is the source-only remediation reference; no external reviewer approval is claimed.
