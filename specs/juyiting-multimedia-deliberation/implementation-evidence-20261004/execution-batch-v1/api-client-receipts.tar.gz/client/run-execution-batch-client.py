import subprocess,pathlib,os,tarfile
C=pathlib.Path('/home/isp/wsps/worktrees/mmd-text-deliverable-client-20261004');env=os.environ.copy();env.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=str(C))
p=subprocess.run(['git','status','--porcelain','--untracked-files=no'],cwd=C,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True);p.check_returncode();assert not p.stdout.strip(),p.stdout
with tarfile.open('/var/tmp/execution-batch-client-changed.tar.gz') as t:
 for m in t.getmembers():assert m.name in ['conf/codex-ws-agent/juyiting-action-outcome.mjs', 'conf/codex-ws-agent/test/juyiting-action-outcome.test.mjs']
 t.extractall(C)
log=pathlib.Path('/var/tmp/mmd-execution-batch-client-tests-v1.log')
with log.open('wb') as out:p=subprocess.run(['node','--test','test/juyiting-action-outcome.test.mjs','test/juyiting-typed-runtime.test.mjs','test/juyiting-typed-outcome.test.mjs','test/typed-inspection-runtime.test.mjs'],cwd=C/'conf/codex-ws-agent',stdout=out,stderr=subprocess.STDOUT,env=env)
pathlib.Path('/var/tmp/mmd-execution-batch-client-tests-v1.exit').write_text(str(p.returncode)+'\n')
print(log.read_text(errors='replace')[-6500:]);raise SystemExit(p.returncode)
