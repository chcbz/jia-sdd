from pathlib import Path
import subprocess,json,collections
results=[]
for name in ['src/components/juyiting/BountyExecutionOutputs.vue','tests/juyiting-bounty-output-gallery.test.js']:
 old=subprocess.check_output(['git','show','f60cfbf:'+name])
 records=[]
 for label,data in [('baseline',old),('current',Path(name).read_bytes())]:
  p=subprocess.run(['node','./node_modules/eslint/bin/eslint.js','--stdin','--stdin-filename',name,'-f','json'],input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  parsed=json.loads(p.stdout.decode('utf-8'))
  messages=parsed[0]['messages']; counts=collections.Counter((m.get('ruleId'),m['message'],m['severity']) for m in messages)
  records.append((label,counts)); results.append({'path':name,'label':label,'exitCode':p.returncode,'diagnostics':messages})
 print(name,'baseline',sum(records[0][1].values()),'current',sum(records[1][1].values()),'new',list((records[1][1]-records[0][1]).elements()))
 assert not records[1][1]-records[0][1]
Path('work/execution-batch-web-lint-comparison.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

