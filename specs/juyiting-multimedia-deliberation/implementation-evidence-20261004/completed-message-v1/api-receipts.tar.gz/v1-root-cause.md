# Completed message source v1: evidence-based repair

Exact API 62b4c776/tree25dc5bc8; agent mmdU3Finalization natural exit1, 57 tests, 2 assertion failures. Raw /var/tmp/mmd-completed-message-tests-20261004/agent-v1.log and JUnit XML retained.

Root cause: fixture jdbc.manifest is an artifact identifier, not published JSON bytes. Two new assertions read the wrong field. Repair captures actual publish contentBytes on application/json, not an invented JDBC projection. Normal Gradle graph and assertions retained.

Production investigation also shows natural typed CHAT admission has no interaction-step row. Require actual typed admission/turn/message/snapshot; never fabricate step, source execution or run. Message selection now has null step; mixed media legacy references unchanged. Current grant authorization remains the existing promotion boundary; reader output itself is not promotion authority. Tests assert absent step and actual original UTF8 bytes. PowerShell-created test scripts used GBK by default; explicit UTF8 source encoding restored before candidate v2.

Next: source-only agent finalization and chat source/final/media regressions; no provider, DB writes, release or deploy.
