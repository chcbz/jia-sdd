import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
from pathlib import Path
import subprocess, json, hashlib,collections
runs=[('tests',['node','--import','tsx','./node_modules/mocha/bin/mocha.js','--no-config','--require','./tests/setup.js','--reporter','spec',
 'tests/juyiting-explicit-execution-delivery.test.js','tests/juyiting-completed-text-delivery.test.js','tests/juyiting-bounty-output-gallery.test.js','tests/juyiting-bounty-acceptance.test.js','tests/juyiting-bounty-finalization.test.js','tests/juyiting-bounty-output-catalog.test.js','tests/juyiting-typed-deliberation-wire.test.js','tests/juyiting-finalization-task-refresh.test.js','tests/juyiting-typed-deliberation-interaction.test.js','tests/juyiting-action-outcome-v3.test.js']),
 ('lint',['node','./node_modules/eslint/bin/eslint.js','src/composables/juyiting/hallTypedDeliberation.js','src/composables/juyiting/bountyOutputCatalog.js','src/composables/juyiting/useHallTypedDeliberation.js','tests/juyiting-typed-deliberation-interaction.test.js','tests/juyiting-explicit-execution-delivery.test.js','tests/juyiting-completed-text-delivery.test.js']),
 ('build',['node','./node_modules/vite/bin/vite.js','build'])]
results=[]
for name,cmd in runs:
 log=Path('work')/('media-basis-web-'+name+'-v4.log')
 with log.open('wb') as out: p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exitCode':p.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 print(name,p.returncode,flush=True)
 if p.returncode: print(log.read_text(encoding='utf-8',errors='replace')[-3500:]); break
Path('work/media-basis-web-v4-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
raise SystemExit(any(r['exitCode'] for r in results))
