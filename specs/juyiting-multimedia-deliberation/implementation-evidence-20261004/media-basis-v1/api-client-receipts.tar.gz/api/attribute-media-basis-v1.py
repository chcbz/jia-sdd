import subprocess,tarfile,pathlib
C=pathlib.Path('/home/isp/wsps/worktrees/mmd-attachment-only-20261004');E=pathlib.Path('/var/tmp/mmd-media-basis-tests-v1-20261004')
with tarfile.open(E/'junit-failed.tar.gz','w:gz') as t:
 for p in (C/'chat/jia-chat-service/build/test-results/chatDeliberation').glob('TEST-*.xml'):t.add(p,arcname=p.name)
p=subprocess.run(['python3','/home/isp/wsps/cyf/ops/orchestration/cyf_orchestrator.py','fail','MMD-T05-MEDIA-BASIS-20261004','--category','test_fixture_nested_stubbing','--summary','137 scoped tests: 135 pass, two new admission fixtures unfinished Mockito stubbing','--evidence',str(E/'chat-v1.log'),'--root-cause','Calling actual mixed final read inside thenReturn touches mocked readers while stubbing remains open','--remediation','Compute actual projection before starting stubbing in both tests; archive failed XML and rerun original normal graph'])
assert p.returncode==1,'Expected attributed fail exit1'
