import importlib.util,json,subprocess,os,pathlib
O='/home/isp/wsps/cyf/ops/orchestration/cyf_orchestrator.py'
s=importlib.util.spec_from_file_location('orch',O);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
T='MMD-T05-OUTPUT-LINEAGE-20261004'
S='0ff0322b08ab5c01208e7bb764be72ce3d4849e3';R='434913fd4dd7fefe06cd5ed3060c5805b1aeec5c'
C='/home/isp/wsps/worktrees/mmd-attachment-only-20261004'
env=os.environ.copy();env.update(JAVA_HOME='/home/isp/apps/jdk21',GRADLE_USER_HOME='/root/.gradle',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=C)
env['PATH']='/home/isp/apps/jdk21/bin:'+env['PATH']
for command in [['git','status','--porcelain','--untracked-files=no'],['git','fetch','/var/tmp/mmd-output-lineage-api.bundle','HEAD'],['git','merge','--ff-only',S]]:
 p=subprocess.run(command,cwd=C,env=env,universal_newlines=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(p.stdout);p.check_returncode()
 if command[1]=='status' and p.stdout.strip():raise SystemExit('Tracked remote changes; preserve and stop')
with m.exclusive_lock(m.CONTROL_LOCK):
 ledger=m.load_ledger()
 if T not in ledger['tasks']:
  ledger['tasks'][T]={'owner':None,'exact_sha_tree':{'commit_sha':S,'tree_sha':R},'current_gate':'implementing','blocker':None,'next_action':'T05 exact output lineage normal source tests, no Provider/DDL/release'}
  errors=m.validate_ledger(ledger)
  if errors:raise SystemExit(str(errors))
  m.save_ledger(ledger)
subprocess.run(['python3',O,'transition',T,'--gate','targeted_verification','--agent','mmd-output-lineage-main-20261004','--profile','gpt-6.1-sol','--mode','writer','--commit-sha',S,'--tree-sha',R,'--next-action','Owner scoped edit lineage and original catalog regression; normal graph, no Provider or deploy'],check=True)
E=pathlib.Path('/var/tmp/mmd-output-lineage-tests-20261004');E.mkdir(exist_ok=True)
init='/var/tmp/mmd-attachment-only-tests-20261004/verification.init.gradle'
common=['./gradlew','--no-daemon','--offline','--configure-on-demand','--max-workers=1','--include-build','plugin','-I',init,'-Dorg.gradle.jvmargs=-Xmx384m -XX:MaxMetaspaceSize=256m -XX:+UseSerialGC -XX:ActiveProcessorCount=2']
# Each selector belongs to its Test task. Sequential orchestrated builds retain the shared Gradle lock.
for label,task,tests in [('agent',':agent:jia-agent-service:mmdControlledImageFollowupV3',['cn.jia.agent.service.impl.PersonalWorkspaceConversationExecutionTest','cn.jia.agent.service.impl.PersonalWorkspaceControlledImageV3ExecutionTest']),('chat',':chat:jia-chat-service:chatDeliberation',['cn.jia.chat.api.ChatBountyMediaControllerTest'])]:
 cmd=['python3',O,'gradle','--cwd',C,'--tree-sha',R,'--selector','output-lineage-'+label+'-v1','--fixture-digest','no-db-source-plugin-v1',T,'--']+common+[task]
 for test in tests:cmd+=['--tests',test]
 with (E/(label+'-v1.log')).open('wb') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 (E/(label+'-v1.exit')).write_text(str(p.returncode)+'\n')
 print(label+' NATURAL_EXIT='+str(p.returncode));print((E/(label+'-v1.log')).read_text(errors='replace')[-6000:])
 if p.returncode:raise SystemExit(p.returncode)
