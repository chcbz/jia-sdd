import pathlib,subprocess,json
E=pathlib.Path('work/output-lineage');E.mkdir(parents=True,exist_ok=True)
tests=['juyiting-bounty-output-catalog.test.js','juyiting-bounty-output-gallery.test.js','juyiting-bounty-output-recovery.test.js','juyiting-bounty-inline-results.test.js','juyiting-bounty-finalization.test.js','juyiting-finalization-task-refresh.test.js','juyiting-component-behavior.test.js','juyiting-hall-conversation.test.js']
cmd=['node','--import','tsx','./node_modules/mocha/bin/mocha.js','--no-config','--require','./tests/setup.js','--reporter','dot','--timeout','10000','--exit']+['tests/'+t for t in tests]
with (E/'web-tests.log').open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(E/'web-tests.exit').write_text(str(p.returncode)+'\n');print('TEST_EXIT='+str(p.returncode));print((E/'web-tests.log').read_text(encoding='utf-8',errors='replace')[-1200:].encode('ascii','backslashreplace').decode())
# Preserve current and HEAD baseline lint outputs, compare the same rule/location tuples.
for label,path in [('baseline',str(E/'BountyExecutionOutputs.vue')),('current','src/components/juyiting/BountyExecutionOutputs.vue')]:
 p=subprocess.run(['cmd','/c','npx','eslint','--no-ignore','-f','json',path],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (E/('lint-'+label+'.json')).write_bytes(p.stdout)
 messages=json.loads(p.stdout.decode('utf-8'))[0]['messages'];print(label+' lint='+str(len(messages)))
p=subprocess.run(['cmd','/c','npx','eslint','src/composables/juyiting/bountyOutputCatalog.js','tests/juyiting-bounty-output-catalog.test.js'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(E/'lint-scoped.log').write_bytes(p.stdout);print('SCOPED_LINT_EXIT='+str(p.returncode))
with (E/'web-build.log').open('wb') as f:p=subprocess.run(['cmd','/c','npm','run','build'],stdout=f,stderr=subprocess.STDOUT)
(E/'web-build.exit').write_text(str(p.returncode)+'\n');print('BUILD_EXIT='+str(p.returncode))
# Restore only our own clean HEAD's generated declarations, never source changes.
for file in ['src/auto-imports.d.ts','src/components.d.ts']:
 pathlib.Path(file).write_bytes(subprocess.check_output(['git','show','HEAD:'+file]))
