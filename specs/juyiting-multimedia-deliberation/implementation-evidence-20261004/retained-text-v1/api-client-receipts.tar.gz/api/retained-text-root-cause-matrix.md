# Retained text test-only remediation, 2026-10-05

| Run | Evidence | Root cause | Bounded fix |
| --- | --- | --- | --- |
| v1 | chat-v1.exit0, scoped119 passed | No failure | Production/API chain first passed |
| v2 | /var/tmp/mmd-retained-text-tests-v2-20261004/chat-v1.log | New contract test calls existing facts() fixture with checked Exception but omitted declaration | Add throws Exception to new JUnit method only |
| v3 | /var/tmp/mmd-retained-text-tests-v3-20261004/chat-v1.log, junit-failed.tar.gz, 120 run/1 failure | Plain completed-message fixture stubs lookup by request only; new retained-target traversal correctly uses exact scoped findOutcome(id), which Mockito returned null | Stub that exact original outcome ID in newly extended admission fixture; do not relax unavailable checks |

Normal Gradle/AP dependency graph and shared lock retained. New retained chain/target source tests already pass; production remains unchanged from8ba4db36. Repair tests under standing development authorization. No Provider/payment, production DB/DDL, release or deploy. Rerun all12 scoped suites on repaired exact commit/tree before any push/source-verified transition. Preserve failures; this matrix is not human approval or release authorization.
