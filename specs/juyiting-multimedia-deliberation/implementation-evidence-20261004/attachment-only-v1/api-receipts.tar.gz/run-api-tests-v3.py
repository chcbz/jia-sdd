import os, subprocess, pathlib
E=pathlib.Path('/var/tmp/mmd-attachment-only-tests-20261004')
O='/home/isp/wsps/cyf/ops/orchestration/cyf_orchestrator.py'
T='MMD-T04-ATTACHMENT-ONLY-20261004'
S='7a9418c3c4dfa5d4850b7eb02b091bdbaa2de88b'
R='a6e4f83f0d4f17fead130c85e7467ac586e6ef8a'
C='/home/isp/wsps/worktrees/mmd-attachment-only-20261004'
init=E/'verification.init.gradle'
init.write_text("// Test-only publishing placeholders. Normal source graph, no publishing.\ngradle.beforeProject { project ->\n if (project == project.rootProject) {\n project.ext.snapshotsRepoUrl = 'https://maven.aliyun.com/repository/public'\n project.ext.releasesRepoUrl = 'https://maven.aliyun.com/repository/public'\n project.ext.repoUsername = ''\n project.ext.repoPassword = ''\n }\n}\ngradle.projectsEvaluated {\n rootProject.allprojects.each { project ->\n project.tasks.withType(Test).configureEach { maxParallelForks = 1; maxHeapSize = '192m'; jvmArgs '-XX:+UseSerialGC', '-XX:ActiveProcessorCount=2' }\n }\n}\n")
subprocess.run(['python3',O,'transition',T,'--gate','targeted_verification','--agent','mmd-attachment-only-main-20261004','--profile','gpt-6.1-sol','--mode','writer','--commit-sha',S,'--tree-sha',R,'--next-action','T04 normal graph test with source-included settings plugin and known test-only publishing placeholders; preserve v1 failure. No Provider or deployment.'],check=True)
env=os.environ.copy();env.update(JAVA_HOME='/home/isp/apps/jdk21',GRADLE_USER_HOME='/root/.gradle',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=C)
env['PATH']='/home/isp/apps/jdk21/bin:'+env['PATH']
cmd=['python3',O,'gradle','--cwd',C,'--tree-sha',R,'--selector','attachment-only-wire-durable-continuation-v3','--fixture-digest','no-db-source-plugin-v3',T,'--','./gradlew','--no-daemon','--offline','--configure-on-demand','--max-workers=1','--include-build','plugin','-I',str(init),'-Dorg.gradle.jvmargs=-Xmx384m -XX:MaxMetaspaceSize=256m -XX:+UseSerialGC -XX:ActiveProcessorCount=2',':chat:jia-chat-service:chatDeliberation']
for test in ['cn.jia.chat.api.ChatTypedDeliberationControllerTest','cn.jia.chat.service.ChatDeliberationServiceTest','cn.jia.chat.service.ChatActionContinuationTest','cn.jia.chat.service.ChatTypedDiscussionAdmissionServiceTest','cn.jia.chat.service.ChatTypedDeliberationContextServiceTest']:cmd+=['--tests',test]
with (E/'gradle-v3.log').open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(E/'gradle-v3.exit').write_text(str(r.returncode)+'\n')
print('NATURAL_EXIT='+str(r.returncode));print((E/'gradle-v3.log').read_text(errors='replace')[-6000:])
