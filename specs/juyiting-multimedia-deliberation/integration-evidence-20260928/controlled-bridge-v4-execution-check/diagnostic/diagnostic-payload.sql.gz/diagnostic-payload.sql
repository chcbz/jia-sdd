CREATE TABLE agent_personal_workspace_execution (
  id BIGINT NOT NULL AUTO_INCREMENT,
  execution_id VARCHAR(100) COLLATE utf8mb4_0900_bin NOT NULL,
  owner_jiacn VARCHAR(50) COLLATE utf8mb4_0900_bin NOT NULL,
  task_id VARCHAR(100) COLLATE utf8mb4_0900_bin NOT NULL,
  run_id VARCHAR(100) COLLATE utf8mb4_0900_bin NOT NULL,
  execution_mode VARCHAR(20) COLLATE utf8mb4_0900_bin NOT NULL,
  execution_state VARCHAR(30) COLLATE utf8mb4_0900_bin NOT NULL,
  permitted_operation VARCHAR(40) COLLATE utf8mb4_0900_bin DEFAULT NULL,
  output_content_mime_type VARCHAR(127) COLLATE utf8mb4_0900_bin NOT NULL,
  conversation_lease_version BIGINT DEFAULT NULL,
  conversation_provider_started_at BIGINT DEFAULT NULL,
  conversation_provider_lease_version BIGINT DEFAULT NULL,
  tenant_id VARCHAR(50) COLLATE utf8mb4_0900_bin NOT NULL,
  client_id VARCHAR(50) COLLATE utf8mb4_0900_bin NOT NULL,
  update_time BIGINT DEFAULT NULL,
  PRIMARY KEY(id),
  UNIQUE KEY uk_pwex_fixture_execution(tenant_id,client_id,owner_jiacn,execution_id),
  UNIQUE KEY uk_pwex_fixture_run(tenant_id,client_id,owner_jiacn,task_id,run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin;
ALTER TABLE agent_personal_workspace_execution
  ADD COLUMN controlled_consent_id VARCHAR(100) COLLATE utf8mb4_0900_bin DEFAULT NULL AFTER permitted_operation,
  ADD UNIQUE KEY uk_pwex_controlled_consent (tenant_id,client_id,owner_jiacn,controlled_consent_id),
  ADD CONSTRAINT chk_pwex_controlled_consent CHECK (
    controlled_consent_id IS NULL OR
    (execution_mode='CONVERSATION'
      AND controlled_consent_id REGEXP BINARY '^consent_[0-9a-f]{32}$'
      AND permitted_operation='GENERATE_IMAGE'
      AND output_content_mime_type='image/png'));
